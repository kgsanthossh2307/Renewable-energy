// Renewable Energy Dashboard Application
class RenewableEnergyDashboard {
    constructor() {
        this.currentTab = 'overview';
        this.selectedCountry = 'India';
        this.comparisonMode = false;
        this.charts = {};
        
        // Data from the provided JSON
        this.data = {
            countries: {
                "India": {
                    total_installed_capacity_2024: "441.97 GW",
                    renewable_capacity_2024: "190.57 GW",
                    renewable_share: "43.12%",
                    growth_2015_2024: "134.63%",
                    top_renewable_sources: {
                        "Solar": "81.81 GW (56.95%)",
                        "Wind": "45.89 GW (31.95%)",
                        "Bio Power": "10.95 GW (7.62%)",
                        "Small Hydro": "Remainder"
                    },
                    top_states: ["Gujarat", "Rajasthan", "Tamil Nadu", "Karnataka", "Maharashtra"],
                    additions_2024: "18.56 GW",
                    data_source: "Ministry of New and Renewable Energy (MNRE), Government of India"
                },
                "China": {
                    total_installed_capacity_2024: "3,349 GW",
                    renewable_capacity_2024: "1,843 GW",
                    renewable_share: "55%",
                    additions_2024: "370.9 GW",
                    solar_capacity: "887 GW",
                    wind_capacity: "521 GW",
                    hydro_capacity: "436 GW",
                    nuclear_capacity: "61 GW",
                    target_2030: "1,200 GW wind and solar",
                    renewable_target_2025: "200 GW annual additions",
                    data_source: "National Energy Administration (NEA), China"
                },
                "Japan": {
                    renewable_share_2022: "22.7%",
                    renewable_target_2030: "36-38%",
                    renewable_target_2040: "40-50%",
                    nuclear_target_2040: "20%",
                    thermal_target_2040: "30-40%",
                    total_capacity_2019: "69 GW estimated",
                    renewable_capacity_2019: "26.2 GW",
                    feed_in_tariff: "Active for rooftop solar",
                    data_source: "Ministry of Economy, Trade and Industry (METI), Japan"
                },
                "South Korea": {
                    renewable_share_2022: "8.9%",
                    renewable_target_2030: "21.6%",
                    renewable_target_2036: "30.6%",
                    total_capacity_2023: "143.5 GW",
                    renewable_capacity_2023: "30.4 GW",
                    solar_capacity_2023: "23 GW",
                    wind_capacity_2023: "<2 GW",
                    renewable_portfolio_standard: "25% by 2030",
                    data_source: "Ministry of Trade, Industry and Energy, South Korea"
                },
                "Thailand": {
                    total_capacity_2022: "53 GW",
                    renewable_share: "23%",
                    renewable_target_2037: "47% (37% domestic)",
                    renewable_target_2050: "68-74%",
                    solar_target_2037: "Major source",
                    wind_target_2030: "2.5 GW",
                    floating_solar: "45 MW at Sirindhorn Dam",
                    carbon_neutrality_target: "2050",
                    net_zero_target: "2065",
                    data_source: "Energy Policy and Planning Office (EPPO), Ministry of Energy, Thailand"
                },
                "Vietnam": {
                    total_capacity_2019: "55.3 GW",
                    renewable_capacity_2020: "17.43 GW (25.3%)",
                    solar_capacity_2020: "16.26 GW",
                    wind_capacity_2021: "3-5 GW",
                    renewable_target_2030: "32%",
                    renewable_target_2050: "43%",
                    solar_target_2030: "73 GW",
                    wind_target_2030: "38 GW",
                    electricity_generation_2019: "240 TWh",
                    data_source: "Ministry of Industry and Trade (MOIT), Vietnam"
                },
                "Indonesia": {
                    renewable_share_2022: "12.3%",
                    renewable_target_2025: "23%",
                    renewable_target_2030: "19-21% (revised down)",
                    renewable_potential: "3,686 GW technical potential",
                    financially_viable_projects: "333 GW",
                    investment_target_2022: "USD 4 billion",
                    actual_investment_2022: "USD 1.6 billion",
                    required_investment_2030: "USD 28.5 billion",
                    data_source: "Ministry of Energy and Mineral Resources (MEMR), Indonesia"
                }
            },
            consumption: {
                "China": {
                    generation_2024: "9,418 TWh",
                    growth_rate: "4.6%",
                    renewable_generation_growth: {
                        "Solar": "28%",
                        "Wind": "11%",
                        "Hydro": "11%"
                    }
                },
                "India": {
                    renewable_generation_2024: "31.79%",
                    wind_contribution: "57.61%",
                    solar_contribution: "31.29%",
                    state_leaders: ["Rajasthan", "Gujarat", "Karnataka"]
                },
                "Japan": {
                    electricity_consumption_per_capita: "High developed country level",
                    renewable_share_target: "36-38% by 2030",
                    non_fossil_target: "59% by 2030"
                },
                "South Korea": {
                    market_size_2024: "55.6 TWh",
                    projected_2033: "124.7 TWh",
                    growth_rate: "8.6% CAGR",
                    urbanization_rate: "91.9%"
                },
                "Thailand": {
                    electricity_consumption_2023: "203,875 GWh",
                    per_capita_consumption: "3,087 kWh/person",
                    growth_rate: "3.38% CAGR"
                },
                "Vietnam": {
                    electricity_production_2019: "240 TWh",
                    growth_1990_2019: "30-fold increase",
                    target_2030: "572 TWh"
                },
                "Indonesia": {
                    electricity_demand_growth: "6.9% annually",
                    dominated_by: "Industry sector"
                }
            }
        };

        this.chartColors = ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B'];
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initializeCharts();
        this.loadCountryData(this.selectedCountry);
    }

    setupEventListeners() {
        // Tab navigation with explicit click handlers
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const tabName = tab.getAttribute('data-tab');
                console.log('Tab clicked:', tabName); // Debug log
                if (tabName) {
                    this.switchTab(tabName);
                }
            });
        });

        // Country selection
        document.addEventListener('change', (e) => {
            if (e.target.id === 'countrySelect') {
                this.selectedCountry = e.target.value;
                this.loadCountryData(this.selectedCountry);
                this.updateCountryChart();
            }
        });

        // Comparison functionality
        document.addEventListener('click', (e) => {
            if (e.target.id === 'compareBtn') {
                e.preventDefault();
                this.toggleComparison();
            }
            
            if (e.target.id === 'exportBtn') {
                e.preventDefault();
                this.exportData();
            }
        });

        // Comparison selectors
        document.addEventListener('change', (e) => {
            if (e.target.id === 'compare1' || e.target.id === 'compare2') {
                this.updateComparisonChart();
            }
        });
    }

    switchTab(tabName) {
        console.log('Switching to tab:', tabName); // Debug log
        
        if (!tabName) return;
        
        // Hide all tab contents
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });

        // Remove active class from all tabs
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });

        // Show selected tab content
        const targetContent = document.getElementById(tabName);
        const targetTab = document.querySelector(`[data-tab="${tabName}"]`);
        
        console.log('Target content element:', targetContent); // Debug log
        console.log('Target tab element:', targetTab); // Debug log
        
        if (targetContent && targetTab) {
            targetContent.classList.add('active');
            targetTab.classList.add('active');
            this.currentTab = tabName;

            // Initialize charts for specific tabs with a small delay to ensure DOM is ready
            setTimeout(() => {
                if (tabName === 'country-analysis') {
                    this.updateCountryChart();
                } else if (tabName === 'consumption') {
                    this.initializeConsumptionChart();
                } else if (tabName === 'targets') {
                    this.initializeProgressChart();
                }
            }, 100);
        } else {
            console.error('Could not find tab content or tab element for:', tabName);
        }
    }

    initializeCharts() {
        // Delay chart initialization to ensure DOM is ready
        setTimeout(() => {
            this.initializeMarketShareChart();
        }, 100);
    }

    initializeMarketShareChart() {
        const ctx = document.getElementById('marketShareChart');
        if (!ctx || this.charts.marketShare) return;

        const data = {
            labels: ['China', 'India', 'Japan', 'South Korea', 'Thailand', 'Vietnam', 'Indonesia'],
            datasets: [{
                label: 'Renewable Capacity Share',
                data: [87, 8.7, 1.2, 1.4, 0.8, 0.8, 0.1], // Approximate percentages
                backgroundColor: this.chartColors.slice(0, 7),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        };

        this.charts.marketShare = new Chart(ctx, {
            type: 'doughnut',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'point'
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            usePointStyle: true,
                            generateLabels: function(chart) {
                                const data = chart.data;
                                if (data.labels.length && data.datasets.length) {
                                    return data.labels.map((label, i) => {
                                        const meta = chart.getDatasetMeta(0);
                                        const style = meta.controller.getStyle(i);
                                        return {
                                            text: `${label}: ${data.datasets[0].data[i]}%`,
                                            fillStyle: style.backgroundColor,
                                            strokeStyle: style.borderColor,
                                            lineWidth: style.borderWidth,
                                            pointStyle: 'circle',
                                            hidden: isNaN(data.datasets[0].data[i]) || meta.data[i].hidden,
                                            index: i
                                        };
                                    });
                                }
                                return [];
                            }
                        },
                        onClick: function(e, legendItem, legend) {
                            e.stopPropagation();
                            const index = legendItem.index;
                            const chart = legend.chart;
                            const meta = chart.getDatasetMeta(0);
                            meta.data[index].hidden = !meta.data[index].hidden;
                            chart.update();
                        }
                    },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed}% of total Asian capacity`;
                            }
                        }
                    }
                },
                onHover: (event, activeElements) => {
                    event.native.target.style.cursor = activeElements.length ? 'pointer' : 'default';
                }
            }
        });
    }

    loadCountryData(countryName) {
        const country = this.data.countries[countryName];
        if (!country) return;

        const detailsContainer = document.getElementById('countryDetails');
        if (!detailsContainer) return;

        let renewableShare = country.renewable_share || country.renewable_share_2022 || 'N/A';
        let totalCapacity = country.total_installed_capacity_2024 || country.total_capacity_2023 || country.total_capacity_2022 || country.total_capacity_2019 || 'N/A';
        let renewableCapacity = country.renewable_capacity_2024 || country.renewable_capacity_2023 || country.renewable_capacity_2020 || country.renewable_capacity_2019 || 'N/A';
        let additions = country.additions_2024 || 'N/A';

        detailsContainer.innerHTML = `
            <h3>${countryName} - Renewable Energy Overview</h3>
            <div class="country-info">
                <div class="country-stat">
                    <h4>Total Installed Capacity</h4>
                    <div class="value">${totalCapacity}</div>
                </div>
                <div class="country-stat">
                    <h4>Renewable Capacity</h4>
                    <div class="value">${renewableCapacity}</div>
                </div>
                <div class="country-stat">
                    <h4>Renewable Share</h4>
                    <div class="value">${renewableShare}</div>
                </div>
                <div class="country-stat">
                    <h4>2024 Additions</h4>
                    <div class="value">${additions}</div>
                </div>
                <div class="country-stat">
                    <h4>Data Source</h4>
                    <div class="value" style="font-size: 12px;">${country.data_source}</div>
                </div>
            </div>
        `;
    }

    updateCountryChart() {
        const ctx = document.getElementById('countryBreakdownChart');
        if (!ctx) return;

        if (this.charts.countryBreakdown) {
            this.charts.countryBreakdown.destroy();
        }

        const country = this.data.countries[this.selectedCountry];
        if (!country) return;

        let chartData = { labels: [], data: [] };

        if (this.selectedCountry === 'India' && country.top_renewable_sources) {
            chartData.labels = Object.keys(country.top_renewable_sources);
            chartData.data = Object.values(country.top_renewable_sources).map(value => {
                const match = value.match(/(\d+\.?\d*)/);
                return match ? parseFloat(match[1]) : 0;
            });
        } else if (this.selectedCountry === 'China') {
            chartData.labels = ['Solar', 'Wind', 'Hydro', 'Nuclear'];
            chartData.data = [887, 521, 436, 61];
        } else if (this.selectedCountry === 'South Korea') {
            chartData.labels = ['Solar', 'Wind', 'Other'];
            chartData.data = [23, 2, 5.4];
        } else {
            // Default breakdown for other countries
            chartData.labels = ['Solar', 'Wind', 'Hydro', 'Other'];
            chartData.data = [40, 30, 20, 10]; // Placeholder percentages
        }

        this.charts.countryBreakdown = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: 'Capacity (GW)',
                    data: chartData.data,
                    backgroundColor: this.chartColors.slice(0, chartData.labels.length),
                    borderColor: this.chartColors.slice(0, chartData.labels.length),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y} GW`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Capacity (GW)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Renewable Energy Sources'
                        }
                    }
                },
                onHover: (event, activeElements) => {
                    event.native.target.style.cursor = activeElements.length ? 'pointer' : 'default';
                }
            }
        });
    }

    toggleComparison() {
        const comparisonSection = document.getElementById('comparisonSection');
        if (!comparisonSection) return;

        this.comparisonMode = !this.comparisonMode;
        
        if (this.comparisonMode) {
            comparisonSection.classList.remove('hidden');
            setTimeout(() => {
                this.updateComparisonChart();
            }, 100);
        } else {
            comparisonSection.classList.add('hidden');
        }
    }

    updateComparisonChart() {
        const ctx = document.getElementById('comparisonChart');
        if (!ctx) return;

        if (this.charts.comparison) {
            this.charts.comparison.destroy();
        }

        const country1Select = document.getElementById('compare1');
        const country2Select = document.getElementById('compare2');
        
        if (!country1Select || !country2Select) return;

        const country1 = country1Select.value;
        const country2 = country2Select.value;

        const data1 = this.data.countries[country1];
        const data2 = this.data.countries[country2];

        if (!data1 || !data2) return;

        const getNumericValue = (value) => {
            if (typeof value === 'string') {
                const match = value.match(/(\d+\.?\d*)/);
                return match ? parseFloat(match[1]) : 0;
            }
            return value || 0;
        };

        const renewableShare1 = getNumericValue(data1.renewable_share || data1.renewable_share_2022);
        const renewableShare2 = getNumericValue(data2.renewable_share || data2.renewable_share_2022);
        
        const renewableCapacity1 = getNumericValue(data1.renewable_capacity_2024 || data1.renewable_capacity_2023 || data1.renewable_capacity_2020);
        const renewableCapacity2 = getNumericValue(data2.renewable_capacity_2024 || data2.renewable_capacity_2023 || data2.renewable_capacity_2020);

        this.charts.comparison = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Renewable Share (%)', 'Renewable Capacity (GW)'],
                datasets: [{
                    label: country1,
                    data: [renewableShare1, renewableCapacity1],
                    backgroundColor: this.chartColors[0],
                    borderColor: this.chartColors[0],
                    borderWidth: 1
                }, {
                    label: country2,
                    data: [renewableShare2, renewableCapacity2],
                    backgroundColor: this.chartColors[1],
                    borderColor: this.chartColors[1],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                const unit = context.dataIndex === 0 ? '%' : 'GW';
                                return `${context.dataset.label}: ${context.parsed.y} ${unit}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    initializeConsumptionChart() {
        const ctx = document.getElementById('consumptionChart');
        if (!ctx || this.charts.consumption) return;

        const countries = ['China', 'India', 'Thailand', 'Vietnam', 'South Korea'];
        const consumptionData = [9418, 800, 204, 240, 55.6]; // TWh approximations

        this.charts.consumption = new Chart(ctx, {
            type: 'line',
            data: {
                labels: countries,
                datasets: [{
                    label: 'Electricity Consumption (TWh)',
                    data: consumptionData,
                    borderColor: this.chartColors[0],
                    backgroundColor: this.chartColors[0] + '20',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: this.chartColors[0],
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y} TWh`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Consumption (TWh)'
                        }
                    }
                }
            }
        });
    }

    initializeProgressChart() {
        const ctx = document.getElementById('progressChart');
        if (!ctx || this.charts.progress) return;

        const countries = ['China', 'India', 'Japan', 'South Korea', 'Thailand'];
        const currentProgress = [55, 43.12, 22.7, 8.9, 23];
        const targets2030 = [60, 50, 37, 21.6, 47];

        this.charts.progress = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: countries,
                datasets: [{
                    label: 'Current Progress (%)',
                    data: currentProgress,
                    backgroundColor: this.chartColors[2],
                    borderColor: this.chartColors[2],
                    borderWidth: 1
                }, {
                    label: '2030 Targets (%)',
                    data: targets2030,
                    backgroundColor: this.chartColors[0],
                    borderColor: this.chartColors[0],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        position: 'top'
                    },
                    tooltip: {
                        enabled: true,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y}%`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 70,
                        title: {
                            display: true,
                            text: 'Renewable Share (%)'
                        }
                    }
                }
            }
        });
    }

    exportData() {
        try {
            const csvData = this.generateCSVData();
            const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
            
            // Create a download link
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'asian_renewable_energy_data.csv');
            link.style.visibility = 'hidden';
            
            // Add to document, click, and remove
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Clean up
            URL.revokeObjectURL(url);
            
            // Show success message
            alert('Data exported successfully!');
        } catch (error) {
            console.error('Export failed:', error);
            alert('Export failed. Please try again.');
        }
    }

    generateCSVData() {
        const headers = ['Country', 'Renewable Share', 'Total Capacity', 'Renewable Capacity', 'Data Source'];
        const rows = [headers.join(',')];

        Object.entries(this.data.countries).forEach(([country, data]) => {
            const renewableShare = data.renewable_share || data.renewable_share_2022 || 'N/A';
            const totalCapacity = data.total_installed_capacity_2024 || data.total_capacity_2023 || data.total_capacity_2022 || 'N/A';
            const renewableCapacity = data.renewable_capacity_2024 || data.renewable_capacity_2023 || data.renewable_capacity_2020 || 'N/A';
            const dataSource = data.data_source || 'N/A';

            const row = [
                `"${country}"`,
                `"${renewableShare}"`,
                `"${totalCapacity}"`,
                `"${renewableCapacity}"`,
                `"${dataSource}"`
            ];
            rows.push(row.join(','));
        });

        return rows.join('\n');
    }
}

// Initialize the dashboard when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing dashboard');
    new RenewableEnergyDashboard();
});